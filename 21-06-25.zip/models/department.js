module.exports = (sequelize, DataTypes) => {
    const Department = sequelize.define('Department', {
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    }, {
      tableName: 'mst_departments',
    });
  
    Department.associate = function(models) {
      // Associations can be defined here
      Department.hasMany(models.staffWarning, { foreignKey: 'department_id' });
    };
  
    return Department;
  };
  