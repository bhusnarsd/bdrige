module.exports = (sequelize, DataTypes) => {
  const StaffLoginDetails = sequelize.define('staffLoginDetails', {
    staff_id: {
      type: DataTypes.STRING,
      primaryKey: true,
      references: {
        model: 'staff_details', // Table name
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,  // Validates email format
      },
    },
    password: {  // New password field
      type: DataTypes.STRING,
      allowNull: false,  // Password must be provided
    },
    profileImage: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    signatureImage: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  }, {
    tableName: 'staff_login_details',  // Explicitly specifying the table name
    timestamps: true,    // Enable createdAt and updatedAt fields
  });

  // Define associations
  StaffLoginDetails.associate = function(models) {
    StaffLoginDetails.belongsTo(models.StaffDetails, {
      foreignKey: 'staff_id',
      onDelete: 'CASCADE',  // If the staff record is deleted, the associated login details will also be deleted
    });
  }; 

  return StaffLoginDetails;
};
