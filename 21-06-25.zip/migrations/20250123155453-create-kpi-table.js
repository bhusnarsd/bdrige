'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add altering commands here.
     *
     * Example:
     * await queryInterface.createTable('users', { id: Sequelize.INTEGER });
     */
    await queryInterface.createTable('kpi', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      staff_id: {
        type: Sequelize.VARCHAR(20),
        references: {
          model: 'staff_details', // Ensure this table exists
          key: 'id',
        },
        onDelete: 'CASCADE',
      },
      kpi_date: {
        type: Sequelize.DATE,
      },
      department: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      e_period: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      kpi_text1: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      kpi_text2: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      kpi_text3: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      kpi_text4: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      kpi_text5: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      staff_sign: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      hod_sign: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      rating_scale: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      trg1_art: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg1_rwad: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg1_rws: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg1_mbc: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg1_ppc: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg1_sum: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      trg2_pos: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg2_sft: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg2_ccapc: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg2_caos: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg2_ps: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg2_counslng: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg2_sum: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      trg3_cs: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg3_dm: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg3_init: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg3_cp: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg3_gps: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg3_tw: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg3_sum: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      sasndtq1: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      sasndtq2: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      sasndtq3: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      sasndtq4: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      sasndtq5: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      sasndtq6: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      trg_total: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      ps_scale: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      hr_sign: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      director_sign: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      staff_sign1: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      hod_sign1: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      pdf_path: {
        type: Sequelize.TEXT,
        allowNull: true,
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn('now'),  // Default to the current time
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn('now'),  // Default to the current time
      }
    });
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
    await queryInterface.dropTable('kpi');
  }
};
