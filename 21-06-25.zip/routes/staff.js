const express = require('express');
const router = express.Router();
const { registerStaff, staffList, editStaff, updateStaff, getStaffDetails, renderConfidentialityForm, createContract, renderSipCreatePage } = require('../controllers/staffController');
const { addStaffWarning, listStaffWarning, renderWarCreatePage } = require('../controllers/StaffActivityController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/', authMiddleware, staffList);

// Routes for registration
router.get('/enrollment', (req, res) => {
  res.render('staff/enrollment');  // Render the register.ejs file
});


// router.get('/confidentiality-contract', (req, res) => {
//   res.render('staff/confidentiality-contract');  // Render the register.ejs file
// });
router.post('/enrollment', registerStaff);

router.get('/edit/:id',  editStaff);
router.post('/edit/:id',  updateStaff);

router.post('/get-staff-details',  getStaffDetails);
router.get('/confidentiality-contract', authMiddleware, renderConfidentialityForm);
// router.get('/confidentiality-contract', authMiddleware, renderSipCreatePage);
// router.post('/confidentiality-contract', );
// router.get('/confidentiality-contract', authMiddleware, (req, res) => { res.render('staff/confidentiality-contract'); });
router.post('/confidentiality-contract',  createContract);

// router.get('/induction-program', authMiddleware, (req, res) => { res.render('staff/induction-program'); });
router.get('/hr/sip/create', renderSipCreatePage);
router.get('/warning-letter',  renderWarCreatePage  )// (req, res) => { res.render('staff/warning-letter'); });
router.get('/warning-letter/list', listStaffWarning);
router.post('/warning-letter', addStaffWarning);
router.get('/warning-letter', renderWarCreatePage);

// router.get('/end-service', authMiddleware, (req, res) => { res.render('staff/end-service'); });


module.exports = router;
